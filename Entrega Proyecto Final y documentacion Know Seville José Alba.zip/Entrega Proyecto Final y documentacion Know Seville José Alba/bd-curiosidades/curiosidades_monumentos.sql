CREATE DATABASE  IF NOT EXISTS `curiosidades` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `curiosidades`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: curiosidades
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `monumentos`
--

DROP TABLE IF EXISTS `monumentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monumentos` (
  `idMonumento` int NOT NULL AUTO_INCREMENT,
  `tituloMonumento` varchar(45) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  `descripcionMonumento` longtext COLLATE utf8mb4_spanish_ci,
  `imagenMonumento` varchar(256) COLLATE utf8mb4_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`idMonumento`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monumentos`
--

LOCK TABLES `monumentos` WRITE;
/*!40000 ALTER TABLE `monumentos` DISABLE KEYS */;
INSERT INTO `monumentos` VALUES (1,'Hombre de Piedra','En la Sevilla del Siglo XV, en la antigua Calle “Buen Rostro” (actual calle Hombre de Piedra), existía una taberna donde estaba un hombre llamado Mateo Rubio. En la Sevilla del momento, había una orden que se recoge en la placa debajo de la “Cruz de las Culebras” de la Iglesia del Salvador, donde era de obligado cumplimiento arrodillarse al pasar el “Santísimo”. Mateo Rubio desafío esta norma y no se arrodillo. En consecuencia, un rayo cayó sobre él y lo convirtió en piedra.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/hombrepiedra.png'),(2,'Susona','Susona, hija del banquero judío Diego Suson, vivía en Sevilla en el siglo XV. Diego, cansado de los saqueos cristianos, planeó rebelarse ante esta situación.Susona, estando enamorada de un noble cristiano y con el ánimo de protegerle, contó los planes de su padre, a su amado. Los cristianos se anticiparon y ahorcaron a Diego y a su grupo. Arrepentida, Susona se encerró en un convento y dejó un testamento pidiendo que, al morir, su cabeza fuera clavada en la puerta de su casa. ','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/susona.png'),(3,' Calle Sierpes','En el siglo XV, bajo la regencia de Don Alfonso Cárdenas, empezaron a desaparecer niños.  Don Alfonso, recibió un aviso anónimo, que le ofrecía revelar al culpable a cambio de libertad. Acepta la propuesta de un fugitivo que vivía en los subterráneos, identificándose como Melchor Quintana, que le revela que era un basilisco el causante de las desapariciones.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/sierpe.jpg'),(4,'Cabeza del rey Don Pedro','El rey Pedro I “El justiciero” tuvo un ajuste de cuenta, donde asesina al hijo de conde de Niebla de Guzmán.El Conde exigió justicia, solicitando la ejecución del asesino.Don Pedro, aceptó dicha propuesta, siendo ajeno a que había un testigo que  presenció lo ocurrido. El rey Don Pedro, se vio obligado a comprar su silencio. Colocando en una hornacina, un busto suyo tapado .Tras la muerte de Don Pedro, se descubrió la traición al Conde al quedar expuesta la hornacina.  	','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/cabezapedro.png'),(5,'El rostro de la Macarena','El rostro de la Esperanza Macarena de autor desconocido. Está tallado de forma asimétrica,de ahí el que según de donde las mires, parece que se está riendo o está llorando. ','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/macarena.jpg'),(6,'\"Cachorro\"','En Triana vivía un gitano, apodado “Cachorro”. Este se veía a menudo con una mujer casada. Un ataque de celos del marido, provoco el asesinato del “cachorro” tras siete puñaladas. Con posterioridad, se averiguo que no eran amantes y sí  su hermana bastarda. La cara agonizante del gitano, le sirvió al escultor Ruiz de Gijón de inspiración, ya que, fue testigo involuntario de los hechos, a la hora de para tallar  tan extraordinario crucificado.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/cachorro.png'),(7,'Jesus Despojado','Esta extraordinaria talle de imaginería, fue realizada por el escultor Antonio Perea en 1938. Dicha imagen fue realizada estando él en la cárcel, acusado y condenado por ayudar a republicanos. Fue capaz de plasmar en el rostro del cristo, la cara de un condenado a muerte, que compartía celda con él. Con respecto al cuerpo de la imagen, señalar que fue modificado con posterioridad.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/despojado.png'),(8,'Callejón de la Inquisción','Ubicado en el barrio de Triana, junto al castillo de San Jorge. Comunica las actuales calle Castilla  con el paseo de Nuestra Señora de la O, a orillas del río Guadalquivir. El Callejón de la Inquisición tiene unos 35 metros de largo y su nombre se puede leer a la entrada del mismo. Era el camino, que debían de recorrer tanto los condenados a cárcel como los que iban a ser ejecutados a la altura de la Plaza de San Francisco, tras los actos de fe. ','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/callejon.png'),(9,'Castillo de San Jorge','Localizado  justo  al lado del “Callejón de la Inquisición” en pleno corazón de Triana, a orilla del río Guadalquivir. Dichas dependencias, fueron utilizadas en la época como sede de la Santa Inquisición. En este castillo estaban los tribunales, se celebraban juicios e incluso  estaba dotado con celdas, donde encarcelar a los  que iban a ser juzgados o los que ya estaban condenados con pena de muerte. En el siglo XIX fue derribado para convertirse en el actual “Mercado de Abastos”.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/castillo.jpg'),(10,'Carcel del Pópulo','Estaba situada a la altura de lo que en la actualidad conocemos como el mercado del arenal. Eran curiosísimos, los cantos y saetas que con tanto fervor los presos que allí se encontraban encarcelados, le dedicaban a la Esperanza de Triana a su paso por dichas ventanas enrejadas. Esto sirvió de inspiración al compositor  D. Manuel Font para componer la famosa marcha “Soleá dame la mano”.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/populo.png'),(11,'NO&DO','Es el logotipo oficial del Ayuntamiento de Sevilla. Dicho logotipo, tiene su nacimiento en la época del rey Alfonso X. Tras varios conflictos con su hijo Sancho, se vio obligado a refugiarse en Sevilla. Fue tal el cariño y cuidado de los habitantes de Sevilla hacia su persona, que en agradecimiento y  como muestra de gratitud, le otorgo una madeja de oro. De ahí el lema a modo de jeroglífico formado con las sílabas NO y DO con una madeja en medio ( “No-madeja-do”).','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/nofdo.jpg'),(12,'Cocodrilo de la Catedral','En el año 1260 el sultán de Egipto quiso casar a su hijo primogénito con la hija del rey Alfonso X El Sabio, Berenguela. Con ese objetivo, obsequio al rey con varios regalos, entre ellos un cocodrilo, una jirafa y un colmillo de elefante. Dicho objetivo de boda, no se cumplió. Los obsequios recibidos, fueron expuestos en sitios diferentes. Concretamente el cocodrilo fue colocado en uno de los techos de la catedral. En la actualidad, sigue allí una réplica del mismo.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/cocodrilo.jpg'),(13,'L Doña Maria Coronel ','Doña María Coronel  hija de  un copero del rey D. Pedro I. Contrajo matrimonio muy joven con Juan de la Cerda, descendiente de la Familia Real de León. Pronto enviudó. Su marido, fue acusado de conspiración y fue decapitado. Era tal su belleza, que el rey D. Pedro I se enamoró  de ella. Fue tal la situación de acoso, a la que fue sometida por parte del Rey D. Pedro I, que tomo la decisión drástica tras refugiarse en un convento, de rociar su cara con aceite para anular de esta forma, dicha  belleza.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/donamaria.png'),(14,'Santa justa y Rufina','Eran hermanas alfareras de Triana, nacidas en la época de la Sevilla romana. Eran tan cristianas  que durante una procesión de la diosa Venus, se negaron a pagar un tributo al pasar dicha imagen. Esta actitud, provoco en los paganos allí presentes un descontento y agresividad desmedida, llegando a romper y destrozar las cerámicas que tenían expuestas. Como respuesta, las hermanas rompieron la estatua de Venus. Fueron encarceladas y torturadas en las mazmorras situadas en los subterráneos del actual Colegio Salesiano de la Santísima Trinidad.  ','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/justarufina.jpg'),(15,'Santa Librada',' En el siglo VII, Santa Librada, hija del rey de Portugal, rechazó casarse con el rey moro de Sicilia, haciendo voto de castidad y pidiendo a Dios que le hiciera fea. Debido a la desnutrición y al desequilibrio hormonal, le creció vello en el rostro y cuerpo, lo que hizo que el rey moro rechazara el matrimonio. Su padre, no acepto esta decisión tan drástica que había adoptada  su hija. De ahí, que la  acusase  de hereje, teniendo como pena la crucifixión. Por ello, es la única virgen crucificada, estando la imagen ubicada en la iglesia de Salvador.','http://localhost:8080/KnowSeville-TrabajoFindeCiclo/assets/multimedia/galeria/santalibrada.jpg');
/*!40000 ALTER TABLE `monumentos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-31 15:00:13
