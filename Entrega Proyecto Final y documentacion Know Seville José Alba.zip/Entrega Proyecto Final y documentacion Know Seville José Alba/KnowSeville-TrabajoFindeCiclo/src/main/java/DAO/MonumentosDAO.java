package DAO;

import java.sql.SQLException;

import java.util.ArrayList;

import Models.Monumentos;

//import Models.Monumentos;

public interface MonumentosDAO {
	public ArrayList<Monumentos> getMonumentos() throws SQLException; // para el select

}
//CADA TABLA TIENE SU PROPIO DAO