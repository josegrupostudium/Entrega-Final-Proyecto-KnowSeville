package DAOImpl;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import DAO.MonumentosDAO;
import Models.Monumentos;

public class MonumentosDAOImpl implements MonumentosDAO {
	private DataSource pool;
	private InitialContext ctx;

	public MonumentosDAOImpl() throws NamingException {
		this.ctx = new InitialContext();
		// Busca el recurso DataSource en el contexto
		this.pool = (DataSource) ctx.lookup("java:comp/env/jdbc/curiosidades");
	}

	@Override
	public ArrayList<Monumentos> getMonumentos() throws SQLException {
		ArrayList<Monumentos> monumentos = new ArrayList<>();
		try (Connection conn = pool.getConnection();
				Statement stmt = conn.createStatement();
				ResultSet rset = stmt.executeQuery(
						"SELECT idMonumento, tituloMonumento, descripcionMonumento, imagenMonumento FROM monumentos")) {
			while (rset.next()) {
				monumentos.add(new Monumentos(rset.getInt("idMonumento"), rset.getString("tituloMonumento"),
						rset.getString("descripcionMonumento"), rset.getString("imagenMonumento")));
			}
		}
		return monumentos;
	}
}