package Models;

public class Monumentos {
	private Integer idMonumento;
	private String tituloMonumento;
	private String descripcionMonumento;
	private String imagenMonumento;

	public Monumentos(Integer idMonumento, String tituloMonumento, String descripcionMonumento,
			String imagenMonumento) {
		super();
		this.idMonumento = idMonumento;
		this.tituloMonumento = tituloMonumento;
		this.descripcionMonumento = descripcionMonumento;
		this.imagenMonumento = imagenMonumento;

	}

	public Integer getIdMonumento() {
		return idMonumento;
	}

	public void setIdMonumento(Integer idMonumento) {
		this.idMonumento = idMonumento;
	}

	public String getTituloMonumento() {
		return tituloMonumento;
	}

	public void setTituloMonumento(String tituloMonumento) {
		this.tituloMonumento = tituloMonumento;
	}

	public String getDescripcionMonumento() {
		return descripcionMonumento;
	}

	public void setDescripcionMonumento(String descripcionMonumento) {
		this.descripcionMonumento = descripcionMonumento;
	}

	public String getImagenMonumento() {
		return imagenMonumento;
	}

	public void setImagenMonumento(String imagenMonumento) {
		this.imagenMonumento = imagenMonumento;
	}

}