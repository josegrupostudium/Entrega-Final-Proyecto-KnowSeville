package Controller;

import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import DAOImpl.MonumentosDAOImpl;
import Models.Monumentos;
import Services.MonumentosService;

@WebServlet("/MonumentosSetvlet")
public class MonumentosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MonumentosService service;

	public MonumentosServlet(MonumentosService service) {
		this.service = service;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			ArrayList<Monumentos> monumentos = service.getMonumentos();
			request.setAttribute("monumentos", monumentos);
			request.getRequestDispatcher("monumentos.jsp").forward(request, response);
		} catch (SQLException e) {
			request.setAttribute("error", "Error al obtener los monumentos: " + e.getMessage());
			request.getRequestDispatcher("errorPage.jsp").forward(request, response);
		}
	}

}
