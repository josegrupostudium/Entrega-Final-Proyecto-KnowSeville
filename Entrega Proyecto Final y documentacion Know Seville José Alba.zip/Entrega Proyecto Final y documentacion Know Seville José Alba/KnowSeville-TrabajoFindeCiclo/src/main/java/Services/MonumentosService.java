package Services;

import java.sql.SQLException;
import java.util.ArrayList;

import Models.Monumentos;

public interface MonumentosService {
	public ArrayList<Monumentos> getMonumentos() throws SQLException; // para el select
}
